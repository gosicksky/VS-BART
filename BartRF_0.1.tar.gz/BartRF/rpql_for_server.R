# Load necessary library
library(MASS) # for mvrnorm function
library(nnet)
library(fastDummies)
library(rpql)
library(lme4)

generate_data_cluster <- function(seed,cluster_number, cluster_size, fixed_number, rf_number,category) {
  set.seed(seed) # For reproducibility
  
  # Set parameters
  p <- fixed_number  # Number of predictors (example)
  n <- cluster_number # number of clusters
  m <- cluster_size # number of subjects per cluster
  
  bart_id <- rep(1:n, each = m)
  
  N <- n * m
  sigma2 <- 1 # Variance of the noise (example)
  
  # Function to generate f0(x)
  f0 <- function(x) {
    p_half <- floor(p / 2)
    term1 <- 5 * cos(0.5 * pi * (x[p_half + 1] + x[p_half + 2]))
    term2 <-  - 4 * x[p_half + 3] ^ 2 + exp(x[p_half + 4]) * x[1] + 3 * x[p_half + 5] * x[2]
    term3 <- -2 * x[3] * x[4]
    term4 <- 2 * exp(x[5])
    #term1 <- 10*sin(pi*x[p_half + 1]*x[p_half + 2]) + 20*(x[p_half + 3] - 0.5)^2 + 10*x[1] + 5*x[2]
    return(term1 + term2 + term3 + term4)
  }
  
  
  
  x <- matrix(0, nrow = N, ncol = p)
  
  # First half predictors from Bernoulli(0.5)
  x[, 1:floor(p / 2)] <- rbinom(N* floor(p / 2), 1, 0.5)
  
  # Second half predictors from Uniform(0, 1)
  x[, (floor(p / 2) + 1):p] <- runif(N * (p - floor(p / 2)),min = -1, max = 1)
  
  X <- as.data.frame(x)
  for (i in 1:floor(p / 2)) {
    X[,i] <- as.factor(X[,i])
  }
  
  ##random effect
  
  z <- matrix(0, nrow = N, ncol = rf_number)
  for (i in 1:(ceiling(rf_number/2))) {
    for (j in 1:(N/m)) {
      z[(m * (j - 1) + 1):(m * j),i] <- rnorm(1, 0, 1)
    }
  }
  
  for (i in ((ceiling(rf_number/2) + 1):rf_number)) {
    for (j in 1:(N/m)) {
      z[(m * (j - 1) + 1):(m * j),i] <- rbinom(1, 1, 0.5)
    }
  }
  
  Z <- as.data.frame(z)
  
  Z_useful_continuous <- Z[,c(1,2)]
  Z_useful_category <- Z[, (ceiling(rf_number/2) + 1)]
  
  
  if(category == TRUE) {
    for (i in ((ceiling(rf_number/2) + 1):rf_number)) {
      Z[,i] <- as.factor(Z[,i])
    }
    Z_dummy <- cbind(Z_useful_continuous,Z_useful_category,rep(1,N))
    useful_numebr = 4
  } else {
    Z_dummy <- cbind(Z_useful_continuous,Z_useful_category,rep(1,N))
    useful_numebr = 4
  }
  
  mu <- rep(0, useful_numebr)
  rwishart_seed = sample(1:0xffff,1)
  sigma <- rWishart(1, df = useful_numebr + 1, Sigma = diag(useful_numebr))[,,1]
  #make sure the diag of sigma all bigger than 1
  while(any(diag(sigma) < 2)) {
    sigma <- rWishart(1, df = useful_numebr + 1, Sigma = diag(useful_numebr))[,,1]
  }
  
  beta <- mvrnorm(n, mu, sigma)
  beta_matrix <- matrix(0, nrow = N, ncol = useful_numebr)
  for (i in 1:(N/m)) {
    beta_matrix[(m * (i - 1) + 1):(m * i),] <- rep(beta[i,], each = m)
  }
  y <- apply(x, 1, f0) + rowSums(beta_matrix[,1:useful_numebr] * Z_dummy) + rnorm(N, 0, 1)
  return(list(X = X, y = y, bart_id = bart_id, Z = Z, beta = beta,beta_matrix = beta_matrix, Sigma = sigma, fix_effect = apply(x,1,f0), random_effect = rowSums(beta_matrix[,1:useful_numebr] * Z_dummy), Sigma = sigma, random_select = c(1,2,ceiling(rf_number/2) + 1)))
}

rpql_model_fit <- function(seed, data) {
  
  set.seed(seed) # For reproducibility
  
  rpql_X <- data.matrix(dummy_cols(data$X, remove_first_dummy = TRUE, remove_selected_columns = TRUE))
  rpql_Z <- data.matrix(dummy_cols(data$Z, remove_first_dummy = TRUE, remove_selected_columns = TRUE))
  rpql_Z <- data.matrix(data$Z)
  
  #scale continuous variables
  rpql_X[,1:10] <- scale(rpql_X[,1:10])
  #rpql_Z[,1:4] <- scale(rpql_Z[,1:4])
  rpql_Z[,1:3] <- scale(rpql_Z[,1:3])
  scale_y <- scale(data$y)
  
  rpql_X <- cbind(1, rpql_X)
  rpql_Z <- cbind(1, rpql_Z)
  
  fm1 <- lmer(scale_y ~ rpql_X - 1  + (rpql_Z  - 1|data$bart_id))
  fit_sat <- build.start.fit(fm1,gamma = 2)
  
  lambda_seq <- lseq(1e-8,1e-1,length=100)
  rpql_res <- rpqlseq(y = scale_y, X =  rpql_X, Z = list(rpql_Z), id = list(data$bart_id), lambda = lambda_seq,
                      pen.type = "adl", pen.weights = fit_sat$pen.weights, start = fit_sat)
  return(rpql_res)
}


i = 3
rpql_20_6_result <- list()
cnt <- 0
tryCatch({
  cnt <- cnt + 1
  set.seed(i)
  data <- generate_data_cluster(i,200,10,20,5,TRUE)
  rpql_20_6_result[[cnt]] <- rpql_model_fit(i, data)
}, error = function(e) {
  cnt <- cnt - 1
  print(i)
  print(e)
})
