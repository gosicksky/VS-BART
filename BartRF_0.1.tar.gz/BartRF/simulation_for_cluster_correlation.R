library(Rcpp)
library(MASS)
library(invgamma)
library(truncnorm)
library(fBasics)
library(Rcpp)
library(coda)
library(lme4)
library(binaryLogic)
library(BartRF)

lower_matrix <- function(a) {
  n <- length(a)
  dimen <- (1+sqrt(1+8*n))/2
  lower_triangle_matrix <- matrix(0, nrow = dimen, ncol = dimen)
  diag(lower_triangle_matrix) <- 1
  for (i in 2:dimen) {
    lower_triangle_matrix[i,1:(i-1)] <- a[(1+(i-1)*(i-2)/2):(1+(i-1)*(i-2)/2+(i-2))]
  }
  return(lower_triangle_matrix)
}

# Load necessary library
library(MASS) # for mvrnorm function
library(nnet)

generate_data_cluster <- function(seed,cluster_number, cluster_size, fixed_number, rf_number,category) {
  set.seed(seed) # For reproducibility
  
  # Set parameters
  p <- fixed_number  # Number of predictors (example)
  n <- cluster_number # number of clusters
  m <- cluster_size # number of subjects per cluster
  
  bart_id <- rep(1:n, each = m)
  
  N <- n * m
  sigma2 <- 1 # Variance of the noise (example)
  
  # Function to generate f0(x)
  f0 <- function(x) {
    p_half <- floor(p / 2)
    term1 <- 4 * sin(0.5 * pi * (x[p_half + 1] + x[p_half + 2]))
    term2 <- -5 * (x[p_half + 3] ^ 2) * exp(x[p_half + 4]) + 3 * x[p_half + 5]
    term3 <- 1.1 * x[1] - 5 * x[2]
    term4 <- -2 * x[3] * x[4]
    term5 <- 2 * exp(x[5])
    # term1 <- x[1] + x[2] + x[3] + x[4] + x[5]
    # term2 <- x[p_half + 1] + x[p_half + 2] + x[p_half + 3] + x[p_half + 4] + x[p_half + 5]
    # term3 <- 0
    # term4 <- 0
    # term5 <- 0
    return(term1 + term2 + term3 + term4 + term5)
  }
  
  
  
  x <- matrix(0, nrow = N, ncol = p)
  
  # First half predictors from Bernoulli(0.5)
  x[, 1:floor(p / 2)] <- rbinom(N* floor(p / 2), 1, 0.5)
  
  # Second half predictors from Uniform(0, 1) with correlation 0.3
  #x[, (floor(p / 2) + 1):p] <- runif(N * (p - floor(p / 2)),min = 0, max = 1)c
  cor <- 0.3
  x[, (floor(p / 2) + 1):p] <- MASS::mvrnorm(N, rep(0, p - floor(p / 2)), diag(p - floor(p / 2)) * (1 - cor) + cor)
  x[, (floor(p / 2) + 1):p] <- pnorm(x[, (floor(p / 2) + 1):p])
  
  X <- as.data.frame(x)
  for (i in 1:floor(p / 2)) {
    X[,i] <- as.factor(X[,i])
  }
  
  ##random effect
  
  z <- matrix(0, nrow = N, ncol = rf_number)
  for (j in 1:(N/m)) {
    cor <- 0.3
    z[(m * (j - 1) + 1):(m * j),1:floor(rf_number/3)] <- MASS::mvrnorm(m, rep(0, floor(rf_number/3)), diag(floor(rf_number/3)) * (1 - cor) + cor)
    z[(m * (j - 1) + 1):(m * j),1:floor(rf_number/3)] <- pnorm(z[(m * (j - 1) + 1):(m * j),1:floor(rf_number/3)])
  }
  
  for (j in 1:(N/m)) {
    #z[(m * (j - 1) + 1):(m * j),i] <- rnorm(m, mean = runif(1,min = -2, max = 2), sd = 1)
    cor <- 0.3
    z[(m * (j - 1) + 1):(m * j),floor(rf_number/3+1):floor(rf_number/3*2)] <- MASS::mvrnorm(m, rep(sqrt(j), floor(rf_number/3)), diag(floor(rf_number/3)) * (1 - cor) + cor)
  }
  
  for (i in floor(rf_number/3*2+1):rf_number) {
    for (j in 1:(N/m)) {
      z[(m * (j - 1) + 1):(m * j),i] <- rbinom(m, 1, 0.2 * (j %% 4 + 1))
    }
  }
  
  Z <- as.data.frame(z)
  
  Z_useful_continuous <- Z[,c(1,floor(rf_number/3)+1)]
  Z_useful_category <- Z[,floor(rf_number * 2/3)+1]
  
  if(category == TRUE) {
    for (i in (floor(rf_number/3*2)+1):rf_number) {
      Z[,i] <- as.factor(Z[,i])
    }
    Z_dummy <- cbind(Z_useful_continuous,fastDummies::dummy_cols(Z_useful_category)[,2:ncol(fastDummies::dummy_cols(Z_useful_category))])
  } else {
    Z_dummy <- cbind(Z_useful_continuous,Z_useful_category)
  }
  
  useful_numebr = 4
  mu <- rep(0, useful_numebr)
  sigma <- rWishart(1, df = useful_numebr + 1, Sigma = diag(useful_numebr))[,,1]
  beta <- mvrnorm(n, mu, sigma)
  beta_matrix <- matrix(0, nrow = N, ncol = useful_numebr)
  for (i in 1:(N/m)) {
    beta_matrix[(m * (i - 1) + 1):(m * i),] <- rep(beta[i,], each = m)
  }
  y <- apply(x, 1, f0) + rowSums(beta_matrix[,1:useful_numebr] * Z_dummy) + rnorm(N, 0, 1)
  return(list(X = X, y = y, bart_id = bart_id, Z = Z, beta = beta,beta_matrix = beta_matrix, Sigma = sigma, fix_effect = apply(x,1,f0), random_effect = rowSums(beta_matrix[,1:useful_numebr] * Z_dummy), Sigma = sigma, random_select = c(1,floor(rf_number/3)+1,floor(rf_number * 2/3)+1)))
}

taskid <- as.numeric(commandArgs(trailingOnly = TRUE))

print(taskid)

data <- generate_data_cluster(taskid,25,100,100,6,TRUE)

q = ncol(rfModelMatrix(data_cluster$Z)$Z)
c0 <- 0.05   # shape
d0 <- 0.05   # rate
## b: standard normal
## gamma: multivariate normal distribution
gamma_mean  <- rep(0, q*(q-1)/2)
gamma_cov <- 0.5 *diag(q*(q-1)/2)
## lambda: truncated normal distribution
z_alpha <- 2
z_beta <- 5
lambda_mean <- rep(0, q)
lambda_cov <- rep(30, q) #should be square


#test_Z <- (data_cluster$Z[,1:4] %>% group_by(data_cluster$bart_id) %>% mutate_all(scale, center = TRUE, scale = FALSE))[,1:4]
test_Z <- scale(data_cluster$Z[,1:4], center = TRUE, scale = TRUE)
test_Z <- cbind(test_Z,data_cluster$Z[,5:6])

bart_cluster_result <- BartRF::wbart(x.train = as.data.frame(data_cluster$X), y.train = data_cluster$y, z.train = as.data.frame(data_cluster$Z), id = data_cluster$bart_id, nskip = 4000, ndpost = 4000, ntree = 50,
                                     z_c0 = c0, z_d0 = d0,
                                     z_gamma_mean = gamma_mean, z_gamma_cov = gamma_cov,
                                     z_lambda_mean = lambda_mean, z_lambda_cov = lambda_cov, z_alpha = z_alpha, z_beta = z_beta, rm.const = FALSE)

bart_cluster_result